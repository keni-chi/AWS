#config file containing credentials for rds mysql instance
db_username = "{username}"
db_password = "{xxxx}"
db_name = "ExampleDB"

CONTROLLER_ID = 'CONTROLLER_ID'
CONTROLLER_NAME = 'CONTROLLER_NAME'
