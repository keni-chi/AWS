def lambda_handler(event, context):
    print('start')
    print(event)
    return event
